var jwt = require('jsonwebtoken');
const models = require('../models');


module.exports = {

    //generar el token
    encode: async(id, rol) => {

    },
    //permite decodificar el token
    decode: async(token) => {
        try {

        } catch (e) {

        }

    }
}